<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/sql/install.php';
require_once __DIR__ . '/classes/Infrastructure/ConfigRepository.php';
require_once __DIR__ . '/classes/Infrastructure/Logger.php';
require_once __DIR__ . '/classes/Infrastructure/PrestashopWebserviceManager.php';
require_once __DIR__ . '/classes/Api/CashRegisterClient.php';
require_once __DIR__ . '/classes/Api/CashAccountClient.php';
require_once __DIR__ . '/classes/Api/CashApiClient.php';
require_once __DIR__ . '/classes/Repository/ProductRepository.php';
require_once __DIR__ . '/classes/Repository/CombinationRepository.php';
require_once __DIR__ . '/classes/Repository/ProductFieldRepository.php';
require_once __DIR__ . '/classes/Repository/PaymentRepository.php';
require_once __DIR__ . '/classes/Repository/CarrierRepository.php';
require_once __DIR__ . '/classes/Integration/AnProductFieldsAdapter.php';
require_once __DIR__ . '/classes/Order/OrderLineResolver.php';
require_once __DIR__ . '/classes/Order/OrderPayloadBuilder.php';
require_once __DIR__ . '/classes/Order/OrderSyncService.php';
require_once __DIR__ . '/classes/Services/CashDataReader.php';
require_once __DIR__ . '/classes/Services/CashCatalogComparator.php';

class NsCaissePro extends Module
{
    const ADMIN_TABS = array(
        'config' => 'Configuration',
        'data' => 'Données caisse',
        'categories' => 'Catégories',
        'products' => 'Produits',
        'combinations' => 'Déclinaisons',
        'productfields' => 'AN Product Fields',
        'payments' => 'Paiements',
        'carriers' => 'Transporteurs',
        'logs' => 'Logs',
    );

    /** @var NsCaisseProConfigRepository */
    protected $configRepository;

    public function __construct()
    {
        $this->name = 'nscaissepro';
        $this->tab = 'administration';
        $this->version = '3.0.0';
        $this->author = 'NS';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('NS Caisse Pro');
        $this->description = $this->l('Connecteur PrestaShop vers caisse avec support des déclinaisons natives et AN Product Fields.');
        $this->ps_versions_compliancy = array('min' => '1.7.0.0', 'max' => _PS_VERSION_);

        $this->configRepository = new NsCaisseProConfigRepository();
    }

    public function install()
    {
        require_once __DIR__ . '/sql/install.php';

        return parent::install()
            && $this->registerHook('actionValidateOrder')
            && $this->registerHook('displayBackOfficeHeader')
            && NsCaisseProInstaller::install();
    }

    public function uninstall()
    {
        require_once __DIR__ . '/sql/uninstall.php';

        return NsCaisseProUninstaller::uninstall() && parent::uninstall();
    }

    public function hookDisplayBackOfficeHeader()
    {
        if (Tools::getValue('configure') === $this->name && isset($this->context->controller) && method_exists($this->context->controller, 'addCSS')) {
            $this->context->controller->addCSS($this->_path . 'views/css/admin.css');
        }
    }

    public function hookActionValidateOrder($params)
    {
        if (empty($params['order']) || !($params['order'] instanceof Order)) {
            return;
        }

        try {
            $service = $this->buildOrderSyncService((int) $params['order']->id_shop);
            $service->syncByOrder($params['order']);
        } catch (Exception $e) {
            PrestaShopLogger::addLog(
                '[nscaissepro] Sync failed for order #' . (int) $params['order']->id . ': ' . $e->getMessage(),
                3
            );
        }
    }

    public function getContent()
    {
        $output = '';

        if (Tools::isSubmit('submitNsCaisseConfig')) {
            $output .= $this->handleConfigSubmit();
        }

        if (Tools::isSubmit('submitNsCaisseLogin')) {
            $output .= $this->handleLoginSubmit();
        }

        if (Tools::isSubmit('submitNsCaisseCreateAccount')) {
            $output .= $this->handleCreateAccountSubmit();
        }

        if (Tools::isSubmit('submitNsCaisseLogout')) {
            $output .= $this->handleLogoutSubmit();
        }

        if (Tools::isSubmit('submitNsCaisseCreateWsKey')) {
            $output .= $this->handleCreateWsKeySubmit();
        }

        if (Tools::isSubmit('submitNsCaisseProductMap')) {
            $output .= $this->handleProductMapSubmit();
        }

        if (Tools::isSubmit('submitNsCaisseCombinationMap')) {
            $output .= $this->handleCombinationMapSubmit();
        }

        if (Tools::isSubmit('submitNsCaisseProductFieldMap')) {
            $output .= $this->handleProductFieldMapSubmit();
        }

        if (Tools::isSubmit('submitNsCaissePaymentMap')) {
            $output .= $this->handlePaymentMapSubmit();
        }

        if (Tools::isSubmit('submitNsCaisseCarrierMap')) {
            $output .= $this->handleCarrierMapSubmit();
        }

        if (Tools::isSubmit('submitNsCaisseCategoryMap')) {
            $output .= $this->handleCategoryMapSubmit();
        }

        $activeTab = (string) Tools::getValue('ns_tab', 'config');
        if (!array_key_exists($activeTab, self::ADMIN_TABS)) {
            $activeTab = 'config';
        }

        $output .= $this->renderTabs($activeTab);
        $output .= '<div class="panel ns-caisse-panel">';
        $output .= $this->renderActiveTab($activeTab);
        $output .= '</div>';

        return $output;
    }

    protected function renderTabs($activeTab)
    {
        $baseUrl = $this->context->link->getAdminLink('AdminModules', true) . '&configure=' . $this->name;
        $html = '<ul class="nav nav-tabs ns-caisse-tabs">';

        foreach (self::ADMIN_TABS as $key => $label) {
            $class = ($key === $activeTab) ? 'active' : '';
            $html .= sprintf(
                '<li class="%s"><a href="%s&ns_tab=%s">%s</a></li>',
                $class,
                htmlspecialchars($baseUrl, ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($key, ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($this->l($label), ENT_QUOTES, 'UTF-8')
            );
        }

        $html .= '</ul>';

        return $html;
    }

    protected function renderActiveTab($tab)
    {
        switch ($tab) {
            case 'data':
                return $this->renderDataTab();
            case 'categories':
                return $this->renderCategoriesTab();
            case 'products':
                return $this->renderProductsTab();
            case 'combinations':
                return $this->renderCombinationsTab();
            case 'productfields':
                return $this->renderProductFieldsTab();
            case 'payments':
                return $this->renderPaymentsTab();
            case 'carriers':
                return $this->renderCarriersTab();
            case 'logs':
                return $this->renderLogsTab();
            case 'config':
            default:
                return $this->renderConfigTab();
        }
    }

    protected function getSelectedShopId()
    {
        $shopId = (int) Tools::getValue('id_shop');
        if ($shopId > 0) {
            return $shopId;
        }

        return (int) $this->context->shop->id;
    }

    protected function renderShopSelector($name = 'id_shop')
    {
        $selectedShopId = $this->getSelectedShopId();
        $shops = Shop::getShops(true, null, false);

        $html = '<div class="form-group"><label><strong>' . $this->l('Boutique') . '</strong></label>';
        $html .= '<select class="form-control" name="' . htmlspecialchars($name, ENT_QUOTES, 'UTF-8') . '">';

        if (is_array($shops)) {
            foreach ($shops as $shop) {
                $idShop = isset($shop['id_shop']) ? (int) $shop['id_shop'] : 0;
                $shopName = isset($shop['name']) ? $shop['name'] : ('Shop #' . $idShop);
                if ($idShop <= 0) {
                    continue;
                }
                $selected = ($idShop === $selectedShopId) ? ' selected="selected"' : '';
                $html .= '<option value="' . $idShop . '"' . $selected . '>' . htmlspecialchars($shopName, ENT_QUOTES, 'UTF-8') . '</option>';
            }
        }

        $html .= '</select></div>';

        return $html;
    }

    protected function renderConfigTab()
    {
        $shopId = $this->getSelectedShopId();
        $config = $this->configRepository->getByShopId($shopId);
        $syncOnValidate = isset($config['sync_on_validate']) ? (int) $config['sync_on_validate'] : 1;
        $debugMode = isset($config['debug_mode']) ? (int) $config['debug_mode'] : 0;
        $isConnected = !empty($config['api_key']) && !empty($config['cash_shop_id']) && $config['connection_status'] === 'connected';

        $html = '<h3>' . $this->l('Configuration caisse') . '</h3>';
        $html .= '<form method="post">';
        $html .= $this->renderShopSelector();
        $html .= '<div class="form-group"><label>' . $this->l('Actif') . '</label><select class="form-control" name="active"><option value="1"' . (!empty($config['active']) ? ' selected="selected"' : '') . '>Oui</option><option value="0"' . (empty($config['active']) ? ' selected="selected"' : '') . '>Non</option></select></div>';
        $html .= '<div class="form-group"><label>' . $this->l('URL d’envoi des commandes') . '</label><input class="form-control" type="text" name="api_url" value="' . htmlspecialchars(isset($config['api_url']) ? $config['api_url'] : '', ENT_QUOTES, 'UTF-8') . '"><p class="help-block">' . $this->l('Endpoint qui reçoit le payload des commandes. À confirmer ensemble selon l’API de la caisse.') . '</p></div>';
        $html .= '<div class="form-group"><label>' . $this->l('URL de la plateforme caisse') . '</label><input class="form-control" type="text" name="account_base_url" value="' . htmlspecialchars(isset($config['account_base_url']) ? $config['account_base_url'] : 'https://caisse.enregistreuse.fr', ENT_QUOTES, 'UTF-8') . '"></div>';
        $html .= '<div class="form-group"><label>' . $this->l('Clé API caisse') . '</label><input class="form-control" type="text" name="api_key" value="' . htmlspecialchars(isset($config['api_key']) ? $config['api_key'] : '', ENT_QUOTES, 'UTF-8') . '"></div>';
        $html .= '<div class="form-group"><label>' . $this->l('Identifiant boutique caisse (SHOPID)') . '</label><input class="form-control" type="text" name="cash_shop_id" value="' . htmlspecialchars(isset($config['cash_shop_id']) ? $config['cash_shop_id'] : '', ENT_QUOTES, 'UTF-8') . '"></div>';
        $html .= '<div class="form-group"><label>' . $this->l('Clé webservice PrestaShop') . '</label><input class="form-control" type="text" readonly="readonly" value="' . htmlspecialchars(isset($config['ps_ws_key']) ? $config['ps_ws_key'] : '', ENT_QUOTES, 'UTF-8') . '"></div>';
        $html .= '<div class="form-group"><label>' . $this->l('Timeout (secondes)') . '</label><input class="form-control" type="number" min="1" name="timeout" value="' . (int) (isset($config['timeout']) ? $config['timeout'] : 10) . '"></div>';
        $html .= '<div class="form-group"><label>' . $this->l('Synchroniser lors de la validation de commande') . '</label><select class="form-control" name="sync_on_validate"><option value="1"' . ($syncOnValidate ? ' selected="selected"' : '') . '>Oui</option><option value="0"' . (!$syncOnValidate ? ' selected="selected"' : '') . '>Non</option></select></div>';
        $html .= '<div class="form-group"><label>' . $this->l('Mode debug') . '</label><select class="form-control" name="debug_mode"><option value="1"' . ($debugMode ? ' selected="selected"' : '') . '>Oui</option><option value="0"' . (!$debugMode ? ' selected="selected"' : '') . '>Non</option></select></div>';
        $html .= '<button class="btn btn-primary" type="submit" name="submitNsCaisseConfig">' . $this->l('Enregistrer') . '</button>';
        $html .= '</form>';

        $html .= '<hr>';
        $html .= '<h3>' . $this->l('Connexion caisse') . '</h3>';
        $html .= '<div class="alert alert-' . ($isConnected ? 'success' : 'warning') . '">';
        $html .= $isConnected
            ? $this->l('La boutique est connectée à la caisse.')
            : $this->l('La boutique n’est pas encore connectée à la caisse.');
        $html .= '<br><strong>' . $this->l('Statut') . ':</strong> ' . htmlspecialchars((string) $config['connection_status'], ENT_QUOTES, 'UTF-8');
        if (!empty($config['last_connection_at'])) {
            $html .= '<br><strong>' . $this->l('Dernière connexion') . ':</strong> ' . htmlspecialchars((string) $config['last_connection_at'], ENT_QUOTES, 'UTF-8');
        }
        $html .= '</div>';

        $html .= '<div class="row">';
        $html .= '<div class="col-md-6">';
        $html .= '<form method="post">';
        $html .= $this->renderShopSelector();
        $html .= '<div class="form-group"><label>' . $this->l('Login / email caisse') . '</label><input class="form-control" type="text" name="cash_login" value=""></div>';
        $html .= '<div class="form-group"><label>' . $this->l('Mot de passe caisse') . '</label><input class="form-control" type="password" name="cash_password" value=""></div>';
        $html .= '<button class="btn btn-success" type="submit" name="submitNsCaisseLogin">' . $this->l('Se connecter') . '</button> ';
        $html .= '<button class="btn btn-default" type="submit" name="submitNsCaisseCreateWsKey">' . $this->l('Créer / régénérer la clé webservice') . '</button>';
        $html .= '</form>';
        $html .= '</div>';

        $html .= '<div class="col-md-6">';
        $html .= '<form method="post">';
        $html .= $this->renderShopSelector();
        $html .= '<div class="form-group"><label>' . $this->l('Créer un compte caisse avec cet email') . '</label><input class="form-control" type="email" name="create_email" value=""></div>';
        $html .= '<button class="btn btn-info" type="submit" name="submitNsCaisseCreateAccount">' . $this->l('Créer un compte') . '</button> ';
        $html .= '<button class="btn btn-danger" type="submit" name="submitNsCaisseLogout">' . $this->l('Déconnecter') . '</button>';
        $html .= '</form>';
        $html .= '</div>';
        $html .= '</div>';

        return $html;
    }



    protected function renderDataTab()
    {
        $shopId = $this->getSelectedShopId();
        $html = '<h3>' . $this->l('Données caisse') . '</h3>';
        $html .= '<p>' . $this->l('Lecture seule des ressources distantes de la caisse pour préparer les mappings et la synchronisation.') . '</p>';
        $html .= '<form method="get">';
        $html .= '<input type="hidden" name="controller" value="AdminModules">';
        $html .= '<input type="hidden" name="configure" value="' . htmlspecialchars($this->name, ENT_QUOTES, 'UTF-8') . '">';
        $html .= '<input type="hidden" name="ns_tab" value="data">';
        $html .= $this->renderShopSelector();
        $html .= '<button class="btn btn-default" type="submit">' . $this->l('Actualiser') . '</button>';
        $html .= '</form><hr>';

        try {
            $reader = new NsCaisseProCashDataReader(new NsCaisseProCashApiClient($this->configRepository));
            $articles = $reader->getArticles($shopId);
            $departmentGroups = $reader->getDepartmentGroups($shopId);
            $departments = $reader->getDepartments($shopId);
            $declinaisons = $reader->getDeclinaisons($shopId);
            $payments = $reader->getPayments($shopId);
            $livraisons = $reader->getLivraisons($shopId);

            $html .= $this->renderSimpleRemoteTable($this->l('Articles'), $articles, array('id', 'idinterne', 'nomlong', 'prix', 'quantiteDispo', 'idrayon', 'idtauxtva', 'idDeclinaison0', 'idDeclinaison1', 'idDeclinaison2', 'idDeclinaison3', 'idDeclinaison4'));
            $html .= $this->renderSimpleRemoteTable($this->l('Groupes de rayons'), $departmentGroups, array('id', 'nomlong', 'image', 'position'));
            $html .= $this->renderSimpleRemoteTable($this->l('Rayons'), $departments, array('id', 'nomlong', 'idgrouperayon', 'idtauxtva', 'quantiteDispo'));
            $html .= $this->renderSimpleRemoteTable($this->l('Déclinaisons caisse (valeurs)'), $declinaisons, array('id', 'idDeclinaison', 'nom', 'modifPrix', 'description'));
            $html .= $this->renderCashArticleAxesTable($articles);
            $html .= $this->renderSimpleRemoteTable($this->l('Paiements'), $payments, array('id', 'nom', 'nomlong'));
            $html .= $this->renderSimpleRemoteTable($this->l('Livraisons'), $livraisons, array('id', 'nom', 'prix'));
        } catch (Exception $e) {
            $html .= '<div class="alert alert-warning">' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</div>';
        }

        return $html;
    }


    protected function renderSimpleRemoteTable($title, array $rows, array $preferredColumns)
    {
        $html = '<h4>' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</h4>';
        if (empty($rows)) {
            return $html . '<p>' . $this->l('Aucune donnée retournée.') . '</p>';
        }

        $firstRow = reset($rows);
        if (!is_array($firstRow)) {
            return $html . '<pre>' . htmlspecialchars(print_r($rows, true), ENT_QUOTES, 'UTF-8') . '</pre>';
        }

        $columns = array();
        foreach ($preferredColumns as $column) {
            if (array_key_exists($column, $firstRow)) {
                $columns[] = $column;
            }
        }
        if (empty($columns)) {
            $columns = array_slice(array_keys($firstRow), 0, 6);
        }

        $html .= '<div class="table-responsive"><table class="table">';
        $html .= '<thead><tr>';
        foreach ($columns as $column) {
            $html .= '<th>' . htmlspecialchars((string) $column, ENT_QUOTES, 'UTF-8') . '</th>';
        }
        $html .= '</tr></thead><tbody>';

        $count = 0;
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $html .= '<tr>';
            foreach ($columns as $column) {
                $value = isset($row[$column]) ? $row[$column] : '';
                if (is_array($value)) {
                    $value = json_encode($value, JSON_UNESCAPED_UNICODE);
                }
                $html .= '<td>' . htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8') . '</td>';
            }
            $html .= '</tr>';
            $count++;
            if ($count >= 100) {
                break;
            }
        }
        $html .= '</tbody></table></div>';
        if (count($rows) > 100) {
            $html .= '<p class="help-block">' . $this->l('Affichage limité aux 100 premières lignes.') . '</p>';
        }

        return $html;
    }

    protected function renderProductsTab()
    {
        $shopId = $this->getSelectedShopId();
        $repository = new NsCaisseProProductRepository();
        $mappings = $repository->getAllByShopId($shopId);

        $html = '<h3>' . $this->l('Mapping produits simples') . '</h3>';
        $html .= '<p>' . $this->l('Un code caisse par produit simple. Un produit avec déclinaisons doit être configuré dans l’onglet Déclinaisons.') . '</p>';
        $html .= '<form method="post">';
        $html .= $this->renderShopSelector();
        $html .= '<div class="form-group"><label>' . $this->l('Mappings JSON') . '</label>';
        $html .= '<textarea class="form-control ns-json-textarea" name="product_mappings" rows="14">' . htmlspecialchars(json_encode($mappings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8') . '</textarea></div>';
        $html .= '<p class="help-block">' . $this->l('Format attendu : [{"id_product":123,"cash_code":"P001","active":1}]') . '</p>';
        $html .= '<button class="btn btn-primary" type="submit" name="submitNsCaisseProductMap">' . $this->l('Enregistrer') . '</button>';
        $html .= '</form>';

        $html .= '<hr>';
        $html .= '<h3>' . $this->l('Comparaison catalogue PrestaShop / Caisse') . '</h3>';
        $html .= '<p>' . $this->l('Rapprochement prioritaire via idinterne = Pr{id_product}, puis secours par le nom du produit.') . '</p>';

        try {
            $reader = new NsCaisseProCashDataReader(new NsCaisseProCashApiClient($this->configRepository));
            $articles = $reader->getArticles($shopId);
            $departments = $reader->getDepartments($shopId);
            $departmentGroups = $reader->getDepartmentGroups($shopId);
            $comparator = new CashCatalogComparator();
            $compare = $comparator->compare($this->getPrestashopProductsForCompare(), $articles, $departments, $departmentGroups);
            $html .= $this->renderCompareTable($compare);
        } catch (Exception $e) {
            $html .= '<div class="alert alert-warning">' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</div>';
        }

        return $html;
    }


    protected function renderCombinationsTab()
    {
        $shopId = $this->getSelectedShopId();
        $repository = new NsCaisseProCombinationRepository();
        $mappings = $repository->getAllByShopId($shopId);

        $html = '<h3>' . $this->l('Mapping déclinaisons PrestaShop') . '</h3>';
        $html .= '<p>' . $this->l('Le mapping repose sur id_product_attribute pour rester stable, sans analyser le texte de la commande.') . '</p>';
        $html .= '<form method="post">';
        $html .= $this->renderShopSelector();
        $html .= '<div class="form-group"><label>' . $this->l('Mappings JSON') . '</label>';
        $html .= '<textarea class="form-control ns-json-textarea" name="combination_mappings" rows="16">' . htmlspecialchars(json_encode($mappings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8') . '</textarea></div>';
        $html .= '<p class="help-block">' . $this->l('Format attendu : [{"id_product":123,"id_product_attribute":456,"cash_code":"V001","active":1}]') . '</p>';
        $html .= '<button class="btn btn-primary" type="submit" name="submitNsCaisseCombinationMap">' . $this->l('Enregistrer') . '</button>';
        $html .= '</form>';

        $html .= '<hr><h3>' . $this->l('Observation des déclinaisons PrestaShop') . '</h3>';
        $html .= '<p>' . $this->l('Vue de lecture seule pour comprendre la structure des groupes, valeurs et combinaisons avant de travailler les mappings.') . '</p>';
        $html .= $this->renderPrestashopCombinationsObservationTable();

        try {
            $reader = new NsCaisseProCashDataReader(new NsCaisseProCashApiClient($this->configRepository));
            $declinaisons = $reader->getDeclinaisons($shopId);
            $articles = $reader->getArticles($shopId);

            $html .= '<hr><h3>' . $this->l('Observation des déclinaisons caisse') . '</h3>';
            $html .= $this->renderSimpleRemoteTable($this->l('Valeurs de déclinaison caisse'), $declinaisons, array('id', 'idDeclinaison', 'nom', 'modifPrix', 'description'));
            $html .= $this->renderCashArticleAxesTable($articles);
        } catch (Exception $e) {
            $html .= '<div class="alert alert-warning">' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</div>';
        }

        return $html;
    }



    protected function renderProductFieldsTab()
    {
        $shopId = $this->getSelectedShopId();
        $repository = new NsCaisseProProductFieldRepository();
        $mappings = $repository->getAllByShopId($shopId);

        $html = '<h3>' . $this->l('Mapping AN Product Fields') . '</h3>';
        $html .= '<p>' . $this->l('Associe un couple field_name + field_value à un code caisse et à un type de comportement.') . '</p>';
        $html .= '<form method="post">';
        $html .= $this->renderShopSelector();
        $html .= '<div class="form-group"><label>' . $this->l('Mappings JSON') . '</label>';
        $html .= '<textarea class="form-control ns-json-textarea" name="productfield_mappings" rows="16">' . htmlspecialchars(json_encode($mappings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8') . '</textarea></div>';
        $html .= '<p class="help-block">' . $this->l('Format attendu : [{"field_name":"Cuisson","field_value":"Bien cuit","cash_code":"301","type":"option","active":1}]') . '</p>';
        $html .= '<button class="btn btn-primary" type="submit" name="submitNsCaisseProductFieldMap">' . $this->l('Enregistrer') . '</button>';
        $html .= '</form>';

        $html .= '<hr><h3>' . $this->l('Observation AN Product Fields') . '</h3>';
        $html .= '<p>' . $this->l('Lecture des champs, des valeurs parsées avec impact prix, des produits liés et des valeurs réellement utilisées dans les paniers.') . '</p>';

        try {
            $idLang = (int) $this->context->language->id;
            if ($idLang <= 0) {
                $idLang = (int) Configuration::get('PS_LANG_DEFAULT');
            }

            $fields = Db::getInstance()->executeS(
                'SELECT f.id_an_productfields, fl.name, fl.values ' .
                'FROM `' . _DB_PREFIX_ . 'an_productfields` f ' .
                'LEFT JOIN `' . _DB_PREFIX_ . 'an_productfields_lang` fl ON (fl.id_an_productfields = f.id_an_productfields AND fl.id_lang = ' . (int) $idLang . ') ' .
                'ORDER BY f.id_an_productfields ASC'
            );

            $linkedProducts = Db::getInstance()->executeS(
                'SELECT id_an_productfields, id_product, position, is_enabled ' .
                'FROM `' . _DB_PREFIX_ . 'an_productfields_product` ' .
                'ORDER BY id_an_productfields ASC, id_product ASC'
            );

            $cartValues = Db::getInstance()->executeS(
                'SELECT id_an_productfields, id_cart, id_product, id_product_attribute, field_name, field_type, price, value ' .
                'FROM `' . _DB_PREFIX_ . 'an_productfields_cart` ' .
                'ORDER BY id_cart DESC, id_an_productfields ASC'
            );

            $html .= '<h4>' . $this->l('Champs configurés') . '</h4>';
            $html .= '<div class="table-responsive"><table class="table">';
            $html .= '<thead><tr>'
                . '<th>' . $this->l('ID champ') . '</th>'
                . '<th>' . $this->l('Nom du champ') . '</th>'
                . '<th>' . $this->l('Valeurs brutes') . '</th>'
                . '</tr></thead><tbody>';

            if (empty($fields)) {
                $html .= '<tr><td colspan="3">' . $this->l('Aucun champ trouvé.') . '</td></tr>';
            } else {
                foreach ($fields as $field) {
                    $html .= '<tr>'
                        . '<td>' . (int) $field['id_an_productfields'] . '</td>'
                        . '<td>' . htmlspecialchars((string) $field['name'], ENT_QUOTES, 'UTF-8') . '</td>'
                        . '<td>' . htmlspecialchars((string) $field['values'], ENT_QUOTES, 'UTF-8') . '</td>'
                        . '</tr>';
                }
            }
            $html .= '</tbody></table></div>';

            $parsedRows = array();
            if (!empty($fields)) {
                foreach ($fields as $field) {
                    $rawValues = isset($field['values']) ? (string) $field['values'] : '';
                    if ($rawValues === '') {
                        continue;
                    }

                    $items = explode(';', $rawValues);
                    foreach ($items as $item) {
                        $item = trim((string) $item);
                        if ($item === '') {
                            continue;
                        }

                        $impact = '0';
                        $value = $item;

                        if (strpos($item, '$') !== false) {
                            $parts = explode('$', $item, 2);
                            $value = trim((string) $parts[0]);
                            $impact = trim((string) $parts[1]);
                        }

                        $parsedRows[] = array(
                            'field_id' => (int) $field['id_an_productfields'],
                            'field_name' => (string) $field['name'],
                            'value' => $value,
                            'impact_price' => $impact,
                        );
                    }
                }
            }

            $html .= '<h4>' . $this->l('Valeurs parsées avec impact prix') . '</h4>';
            $html .= '<div class="table-responsive"><table class="table">';
            $html .= '<thead><tr>'
                . '<th>' . $this->l('ID champ') . '</th>'
                . '<th>' . $this->l('Nom du champ') . '</th>'
                . '<th>' . $this->l('Valeur') . '</th>'
                . '<th>' . $this->l('Impact prix') . '</th>'
                . '</tr></thead><tbody>';

            if (empty($parsedRows)) {
                $html .= '<tr><td colspan="4">' . $this->l('Aucune valeur parsée trouvée.') . '</td></tr>';
            } else {
                foreach ($parsedRows as $row) {
                    $html .= '<tr>'
                        . '<td>' . (int) $row['field_id'] . '</td>'
                        . '<td>' . htmlspecialchars((string) $row['field_name'], ENT_QUOTES, 'UTF-8') . '</td>'
                        . '<td>' . htmlspecialchars((string) $row['value'], ENT_QUOTES, 'UTF-8') . '</td>'
                        . '<td>' . htmlspecialchars((string) $row['impact_price'], ENT_QUOTES, 'UTF-8') . '</td>'
                        . '</tr>';
                }
            }
            $html .= '</tbody></table></div>';

            $html .= '<h4>' . $this->l('Produits liés aux champs') . '</h4>';
            $html .= '<div class="table-responsive"><table class="table">';
            $html .= '<thead><tr>'
                . '<th>' . $this->l('ID champ') . '</th>'
                . '<th>' . $this->l('ID produit') . '</th>'
                . '<th>' . $this->l('Position') . '</th>'
                . '<th>' . $this->l('Actif') . '</th>'
                . '</tr></thead><tbody>';

            if (empty($linkedProducts)) {
                $html .= '<tr><td colspan="4">' . $this->l('Aucun produit lié trouvé.') . '</td></tr>';
            } else {
                foreach ($linkedProducts as $row) {
                    $html .= '<tr>'
                        . '<td>' . (int) $row['id_an_productfields'] . '</td>'
                        . '<td>' . (int) $row['id_product'] . '</td>'
                        . '<td>' . (int) $row['position'] . '</td>'
                        . '<td>' . (int) $row['is_enabled'] . '</td>'
                        . '</tr>';
                }
            }
            $html .= '</tbody></table></div>';

            $html .= '<h4>' . $this->l('Valeurs réellement utilisées dans les paniers') . '</h4>';
            $html .= '<div class="table-responsive"><table class="table">';
            $html .= '<thead><tr>'
                . '<th>' . $this->l('ID champ') . '</th>'
                . '<th>' . $this->l('Panier') . '</th>'
                . '<th>' . $this->l('Produit') . '</th>'
                . '<th>' . $this->l('Déclinaison') . '</th>'
                . '<th>' . $this->l('Nom du champ') . '</th>'
                . '<th>' . $this->l('Type') . '</th>'
                . '<th>' . $this->l('Valeur') . '</th>'
                . '<th>' . $this->l('Prix') . '</th>'
                . '</tr></thead><tbody>';

            if (empty($cartValues)) {
                $html .= '<tr><td colspan="8">' . $this->l('Aucune valeur panier trouvée.') . '</td></tr>';
            } else {
                $count = 0;
                foreach ($cartValues as $row) {
                    $html .= '<tr>'
                        . '<td>' . (int) $row['id_an_productfields'] . '</td>'
                        . '<td>' . (int) $row['id_cart'] . '</td>'
                        . '<td>' . (int) $row['id_product'] . '</td>'
                        . '<td>' . (int) $row['id_product_attribute'] . '</td>'
                        . '<td>' . htmlspecialchars((string) $row['field_name'], ENT_QUOTES, 'UTF-8') . '</td>'
                        . '<td>' . htmlspecialchars((string) $row['field_type'], ENT_QUOTES, 'UTF-8') . '</td>'
                        . '<td>' . htmlspecialchars((string) $row['value'], ENT_QUOTES, 'UTF-8') . '</td>'
                        . '<td>' . htmlspecialchars((string) $row['price'], ENT_QUOTES, 'UTF-8') . '</td>'
                        . '</tr>';
                    $count++;
                    if ($count >= 100) {
                        break;
                    }
                }
            }
            $html .= '</tbody></table></div>';
        } catch (Exception $e) {
            $html .= '<div class="alert alert-warning">' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</div>';
        }

        return $html;
    }


    protected function renderPaymentsTab()
    {
        $shopId = $this->getSelectedShopId();
        $repository = new NsCaisseProPaymentRepository();
        $mappings = $repository->getAllByShopId($shopId);

        $html = '<h3>' . $this->l('Mapping moyens de paiement') . '</h3>';
        $html .= '<form method="post">';
        $html .= $this->renderShopSelector();
        $html .= '<div class="form-group"><label>' . $this->l('Mappings JSON') . '</label>';
        $html .= '<textarea class="form-control ns-json-textarea" name="payment_mappings" rows="12">' . htmlspecialchars(json_encode($mappings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8') . '</textarea></div>';
        $html .= '<p class="help-block">' . $this->l('Format attendu : [{"payment_module":"ps_wirepayment","cash_code":"CB"}]') . '</p>';
        $html .= '<button class="btn btn-primary" type="submit" name="submitNsCaissePaymentMap">' . $this->l('Enregistrer') . '</button>';
        $html .= '</form>';

        return $html;
    }

    protected function renderCarriersTab()
    {
        $shopId = $this->getSelectedShopId();
        $repository = new NsCaisseProCarrierRepository();
        $mappings = $repository->getAllByShopId($shopId);

        $html = '<h3>' . $this->l('Mapping transporteurs') . '</h3>';
        $html .= '<form method="post">';
        $html .= $this->renderShopSelector();
        $html .= '<div class="form-group"><label>' . $this->l('Mappings JSON') . '</label>';
        $html .= '<textarea class="form-control ns-json-textarea" name="carrier_mappings" rows="12">' . htmlspecialchars(json_encode($mappings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8') . '</textarea></div>';
        $html .= '<p class="help-block">' . $this->l('Format attendu : [{"id_carrier":12,"cash_code":"LIV"}]') . '</p>';
        $html .= '<button class="btn btn-primary" type="submit" name="submitNsCaisseCarrierMap">' . $this->l('Enregistrer') . '</button>';
        $html .= '</form>';

        return $html;
    }

    protected function renderLogsTab()
    {
        $shopId = $this->getSelectedShopId();
        $logger = new NsCaisseProLogger();
        $logs = $logger->getLatestByShopId($shopId, 100);

        $html = '<h3>' . $this->l('Historique de synchronisation') . '</h3>';
        $html .= '<form method="get">';
        $html .= '<input type="hidden" name="controller" value="AdminModules">';
        $html .= '<input type="hidden" name="configure" value="' . htmlspecialchars($this->name, ENT_QUOTES, 'UTF-8') . '">';
        $html .= '<input type="hidden" name="ns_tab" value="logs">';
        $html .= $this->renderShopSelector();
        $html .= '<button class="btn btn-default" type="submit">' . $this->l('Filtrer') . '</button>';
        $html .= '</form><hr>';

        $html .= '<div class="table-responsive"><table class="table">';
        $html .= '<thead><tr><th>ID</th><th>Commande</th><th>Statut</th><th>Message</th><th>Date</th></tr></thead><tbody>';
        if (empty($logs)) {
            $html .= '<tr><td colspan="5">' . $this->l('Aucun log pour cette boutique.') . '</td></tr>';
        } else {
            foreach ($logs as $log) {
                $html .= '<tr>';
                $html .= '<td>' . (int) $log['id_log'] . '</td>';
                $html .= '<td>#' . (int) $log['id_order'] . '</td>';
                $html .= '<td><span class="label label-' . ($log['status'] === 'success' ? 'success' : ($log['status'] === 'error' ? 'danger' : 'default')) . '">' . htmlspecialchars($log['status'], ENT_QUOTES, 'UTF-8') . '</span></td>';
                $html .= '<td>' . htmlspecialchars((string) $log['error_message'], ENT_QUOTES, 'UTF-8') . '</td>';
                $html .= '<td>' . htmlspecialchars((string) $log['date_add'], ENT_QUOTES, 'UTF-8') . '</td>';
                $html .= '</tr>';
            }
        }
        $html .= '</tbody></table></div>';

        return $html;
    }



    protected function getPrestashopProductsForCompare()
    {
        $idLang = (int) $this->context->language->id;
        if ($idLang <= 0) {
            $idLang = (int) Configuration::get('PS_LANG_DEFAULT');
        }

        $shopId = (int) $this->context->shop->id;
        $sql = 'SELECT p.id_product, pl.name, p.price, p.id_category_default
'
            . 'FROM `' . _DB_PREFIX_ . 'product` p
'
            . 'INNER JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON (pl.id_product = p.id_product AND pl.id_lang = ' . (int) $idLang . ' AND pl.id_shop = ' . $shopId . ')
'
            . 'ORDER BY p.id_product ASC';

        $rows = Db::getInstance()->executeS($sql);
        if (!is_array($rows)) {
            return array();
        }

        foreach ($rows as &$row) {
            $idProduct = (int) $row['id_product'];
            $row['price_ttc'] = Product::getPriceStatic($idProduct, true, null, 6, null, false, true, 1, false, null, null, $shopId);
            $row['stock'] = StockAvailable::getQuantityAvailableByProduct($idProduct, 0, $shopId);
            $row['category_path'] = $this->buildCategoryPath((int) $row['id_category_default'], $idLang, $shopId);
        }
        unset($row);

        return $rows;
    }

    protected function buildCategoryPath($idCategory, $idLang, $shopId)
    {
        if ($idCategory <= 0) {
            return '';
        }

        $names = array();
        $current = new Category((int) $idCategory, (int) $idLang, (int) $shopId);
        $guard = 0;
        while (Validate::isLoadedObject($current) && (int) $current->id > 0 && $guard < 10) {
            if (!empty($current->name) && (int) $current->id !== 1 && (int) $current->id !== 2) {
                array_unshift($names, $current->name);
            }
            if ((int) $current->id_parent <= 0 || (int) $current->id_parent === (int) $current->id) {
                break;
            }
            $current = new Category((int) $current->id_parent, (int) $idLang, (int) $shopId);
            $guard++;
        }

        return implode(' > ', $names);
    }


    protected function renderCompareTable(array $rows)
    {
        $html = '<div class="table-responsive"><table class="table">';
        $html .= '<thead><tr>'
            . '<th>' . $this->l('ID PS') . '</th>'
            . '<th>' . $this->l('Produit PS') . '</th>'
            . '<th>' . $this->l('Prix HT PS') . '</th>'
            . '<th>' . $this->l('Prix TTC PS') . '</th>'
            . '<th>' . $this->l('Catégorie PS') . '</th>'
            . '<th>' . $this->l('Stock PS') . '</th>'
            . '<th>' . $this->l('ID caisse') . '</th>'
            . '<th>' . $this->l('ID interne') . '</th>'
            . '<th>' . $this->l('Nom caisse') . '</th>'
            . '<th>' . $this->l('Prix caisse') . '</th>'
            . '<th>' . $this->l('Stock caisse') . '</th>'
            . '<th>' . $this->l('Groupe rayon caisse') . '</th>'
            . '<th>' . $this->l('Rayon caisse') . '</th>'
            . '<th>' . $this->l('Statut') . '</th>'
            . '</tr></thead><tbody>';

        if (empty($rows)) {
            $html .= '<tr><td colspan="14">' . $this->l('Aucune donnée de comparaison disponible.') . '</td></tr>';
        } else {
            $i = 0;
            foreach ($rows as $row) {
                $status = isset($row['status']) ? (string) $row['status'] : '';
                $labelClass = 'default';
                if ($status === 'ok') {
                    $labelClass = 'success';
                } elseif ($status === 'prix_diff') {
                    $labelClass = 'warning';
                } elseif ($status === 'absent_caisse' || $status === 'absent_site') {
                    $labelClass = 'danger';
                }

                $groupDisplay = trim((string) $row['cash_group_name']);
                if ($groupDisplay === '' && !empty($row['cash_group_id'])) {
                    $groupDisplay = '#' . $row['cash_group_id'];
                }
                $rayonDisplay = trim((string) $row['cash_rayon_name']);
                if ($rayonDisplay === '' && !empty($row['cash_rayon_id'])) {
                    $rayonDisplay = '#' . $row['cash_rayon_id'];
                }

                $html .= '<tr>'
                    . '<td>' . (int) $row['ps_id'] . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['ps_name'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['ps_price_ht'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['ps_price_ttc'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['ps_category'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['ps_stock'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['cash_id'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['cash_internal'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['cash_name'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['cash_price'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['cash_stock'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . htmlspecialchars((string) $groupDisplay, ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . htmlspecialchars((string) $rayonDisplay, ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td><span class="label label-' . $labelClass . '">' . htmlspecialchars($status, ENT_QUOTES, 'UTF-8') . '</span></td>'
                    . '</tr>';
                $i++;
                if ($i >= 200) {
                    break;
                }
            }
        }

        $html .= '</tbody></table></div>';
        if (count($rows) > 200) {
            $html .= '<p class="help-block">' . $this->l('Affichage limité aux 200 premières lignes.') . '</p>';
        }

        return $html;
    }


    protected function renderCategoriesTab()
    {
        $shopId = $this->getSelectedShopId();
        $idLang = (int) $this->context->language->id;
        if ($idLang <= 0) {
            $idLang = (int) Configuration::get('PS_LANG_DEFAULT');
        }

        $saved = Configuration::get('NSCAISSEPRO_CATEGORY_MAP', null, null, $shopId);
        $saved = $saved ? json_decode($saved, true) : array();

        $html = '<h3>' . $this->l('Mapping Catégories ↔ Rayons caisse') . '</h3>';

        try {

            $reader = new NsCaisseProCashDataReader(new NsCaisseProCashApiClient($this->configRepository));
            $groups = $reader->getDepartmentGroups($shopId);
            $departments = $reader->getDepartments($shopId);

            $categories = Db::getInstance()->executeS(
                'SELECT c.id_category, c.id_parent, cl.name
                FROM `' . _DB_PREFIX_ . 'category` c
                INNER JOIN `' . _DB_PREFIX_ . 'category_lang` cl 
                ON (cl.id_category = c.id_category 
                AND cl.id_lang = ' . (int)$idLang . '
                AND cl.id_shop = ' . (int)$shopId . ')
                ORDER BY c.id_parent ASC'
            );

            $html .= '<form method="post">';
            $html .= $this->renderShopSelector();

            $html .= '<table class="table">';
            $html .= '<thead>
                <tr>
                    <th>Catégorie PS</th>
                    <th>Groupe rayon caisse</th>
                    <th>Rayon caisse</th>
                </tr>
            </thead><tbody>';

            foreach ($categories as $cat) {

                if ($cat['id_category'] <= 2) {
                    continue;
                }

                $id = (int)$cat['id_category'];

                $groupSelected = isset($saved[$id]['group']) ? $saved[$id]['group'] : '';
                $rayonSelected = isset($saved[$id]['rayon']) ? $saved[$id]['rayon'] : '';

                $html .= '<tr>';
                $html .= '<td>' . htmlspecialchars($cat['name']) . '</td>';

                $html .= '<td><select name="cat_group['.$id.']" class="form-control">';
                $html .= '<option value="">--</option>';
                foreach ($groups as $g) {
                    $sel = $groupSelected == $g['id'] ? 'selected' : '';
                    $html .= '<option value="'.$g['id'].'" '.$sel.'>'.$g['nomlong'].'</option>';
                }
                $html .= '</select></td>';

                $html .= '<td><select name="cat_rayon['.$id.']" class="form-control">';
                $html .= '<option value="">--</option>';
                foreach ($departments as $d) {
                    $sel = $rayonSelected == $d['id'] ? 'selected' : '';
                    $html .= '<option value="'.$d['id'].'" '.$sel.'>'.$d['nomlong'].'</option>';
                }
                $html .= '</select></td>';

                $html .= '</tr>';
            }

            $html .= '</tbody></table>';

            $html .= '<button class="btn btn-primary" name="submitNsCaisseCategoryMap">'.$this->l('Enregistrer mapping').'</button>';

            $html .= '</form>';

        } catch (Exception $e) {

            $html .= '<div class="alert alert-danger">'.$e->getMessage().'</div>';

        }

        return $html;
    }



    protected function renderCashArticleAxesTable(array $articles)
    {
        $html = '<h4>' . $this->l('Axes de déclinaisons utilisés par les articles caisse') . '</h4>';

        if (empty($articles)) {
            return $html . '<p>' . $this->l('Aucune donnée retournée.') . '</p>';
        }

        $html .= '<div class="table-responsive"><table class="table">';
        $html .= '<thead><tr>'
            . '<th>' . $this->l('ID caisse') . '</th>'
            . '<th>' . $this->l('ID interne') . '</th>'
            . '<th>' . $this->l('Nom article') . '</th>'
            . '<th>idDeclinaison0</th>'
            . '<th>idDeclinaison1</th>'
            . '<th>idDeclinaison2</th>'
            . '<th>idDeclinaison3</th>'
            . '<th>idDeclinaison4</th>'
            . '</tr></thead><tbody>';

        $count = 0;
        foreach ($articles as $row) {
            if (!is_array($row)) {
                continue;
            }

            $html .= '<tr>'
                . '<td>' . htmlspecialchars((string) (isset($row['id']) ? $row['id'] : ''), ENT_QUOTES, 'UTF-8') . '</td>'
                . '<td>' . htmlspecialchars((string) (isset($row['idinterne']) ? $row['idinterne'] : ''), ENT_QUOTES, 'UTF-8') . '</td>'
                . '<td>' . htmlspecialchars((string) (isset($row['nomlong']) ? $row['nomlong'] : ''), ENT_QUOTES, 'UTF-8') . '</td>'
                . '<td>' . htmlspecialchars((string) (isset($row['idDeclinaison0']) ? $row['idDeclinaison0'] : ''), ENT_QUOTES, 'UTF-8') . '</td>'
                . '<td>' . htmlspecialchars((string) (isset($row['idDeclinaison1']) ? $row['idDeclinaison1'] : ''), ENT_QUOTES, 'UTF-8') . '</td>'
                . '<td>' . htmlspecialchars((string) (isset($row['idDeclinaison2']) ? $row['idDeclinaison2'] : ''), ENT_QUOTES, 'UTF-8') . '</td>'
                . '<td>' . htmlspecialchars((string) (isset($row['idDeclinaison3']) ? $row['idDeclinaison3'] : ''), ENT_QUOTES, 'UTF-8') . '</td>'
                . '<td>' . htmlspecialchars((string) (isset($row['idDeclinaison4']) ? $row['idDeclinaison4'] : ''), ENT_QUOTES, 'UTF-8') . '</td>'
                . '</tr>';

            $count++;
            if ($count >= 100) {
                break;
            }
        }

        $html .= '</tbody></table></div>';
        if (count($articles) > 100) {
            $html .= '<p class="help-block">' . $this->l('Affichage limité aux 100 premières lignes.') . '</p>';
        }

        return $html;
    }

    protected function renderPrestashopCombinationsObservationTable()
    {
        $rows = $this->getPrestashopCombinationObservationRows();

        $html = '<div class="table-responsive"><table class="table">';
        $html .= '<thead><tr>'
            . '<th>' . $this->l('ID produit') . '</th>'
            . '<th>' . $this->l('Produit') . '</th>'
            . '<th>' . $this->l('ID combinaison') . '</th>'
            . '<th>' . $this->l('Déclinaison lisible') . '</th>'
            . '<th>' . $this->l('Référence') . '</th>'
            . '<th>' . $this->l('Impact prix') . '</th>'
            . '</tr></thead><tbody>';

        if (empty($rows)) {
            $html .= '<tr><td colspan="6">' . $this->l('Aucune déclinaison PrestaShop trouvée.') . '</td></tr>';
        } else {
            $count = 0;
            foreach ($rows as $row) {
                $html .= '<tr>'
                    . '<td>' . (int) $row['id_product'] . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['product_name'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . (int) $row['id_product_attribute'] . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['combination_label'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['reference'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '<td>' . htmlspecialchars((string) $row['price_impact'], ENT_QUOTES, 'UTF-8') . '</td>'
                    . '</tr>';
                $count++;
                if ($count >= 200) {
                    break;
                }
            }
        }

        $html .= '</tbody></table></div>';
        if (count($rows) > 200) {
            $html .= '<p class="help-block">' . $this->l('Affichage limité aux 200 premières lignes.') . '</p>';
        }

        return $html;
    }

    protected function getPrestashopCombinationObservationRows()
    {
        $idLang = (int) $this->context->language->id;
        if ($idLang <= 0) {
            $idLang = (int) Configuration::get('PS_LANG_DEFAULT');
        }

        $sql = 'SELECT pa.id_product_attribute, pa.id_product, pa.reference, pa.price AS price_impact, pl.name AS product_name ' .
            'FROM `' . _DB_PREFIX_ . 'product_attribute` pa ' .
            'INNER JOIN `' . _DB_PREFIX_ . 'product_lang` pl ON (pl.id_product = pa.id_product AND pl.id_lang = ' . (int) $idLang . ' AND pl.id_shop = ' . (int) $this->context->shop->id . ') ' .
            'ORDER BY pa.id_product ASC, pa.id_product_attribute ASC';

        $rows = Db::getInstance()->executeS($sql);
        if (!is_array($rows)) {
            return array();
        }

        foreach ($rows as &$row) {
            $product = new Product((int) $row['id_product'], false, (int) $idLang, (int) $this->context->shop->id); $attributes = array(); if (Validate::isLoadedObject($product)) { $attributes = $product->getAttributeCombinationsById((int) $row['id_product_attribute'], (int) $idLang); }
            $parts = array();
            if (is_array($attributes)) {
                foreach ($attributes as $attribute) {
                    $groupName = isset($attribute['group_name']) ? (string) $attribute['group_name'] : '';
                    $attrName = isset($attribute['attribute_name']) ? (string) $attribute['attribute_name'] : '';
                    $parts[] = trim($groupName . ': ' . $attrName);
                }
            }
            $row['combination_label'] = implode(' / ', $parts);
        }

        return $rows;
    }


    protected function handleConfigSubmit()
    {
        $shopId = (int) Tools::getValue('id_shop');
        $data = array(
            'active' => (int) Tools::getValue('active'),
            'api_url' => trim((string) Tools::getValue('api_url')),
            'api_key' => trim((string) Tools::getValue('api_key')),
            'timeout' => max(1, (int) Tools::getValue('timeout')),
            'sync_on_validate' => (int) Tools::getValue('sync_on_validate'),
            'debug_mode' => (int) Tools::getValue('debug_mode'),
            'account_base_url' => trim((string) Tools::getValue('account_base_url')),
            'cash_shop_id' => trim((string) Tools::getValue('cash_shop_id')),
        );

        if ($shopId <= 0) {
            return $this->displayError($this->l('Boutique invalide.'));
        }

        if (empty($data['account_base_url'])) {
            $data['account_base_url'] = 'https://caisse.enregistreuse.fr';
        }

        if (!$this->configRepository->saveByShopId($shopId, $data)) {
            return $this->displayError($this->l('Impossible d’enregistrer la configuration.'));
        }

        return $this->displayConfirmation($this->l('Configuration enregistrée.'));
    }

    protected function handleLoginSubmit()
    {
        $shopId = (int) Tools::getValue('id_shop');
        $login = trim((string) Tools::getValue('cash_login'));
        $password = (string) Tools::getValue('cash_password');

        if ($shopId <= 0) {
            return $this->displayError($this->l('Boutique invalide.'));
        }

        if ($login === '' || $password === '') {
            return $this->displayError($this->l('Le login et le mot de passe sont obligatoires.'));
        }

        try {
            $wsManager = new NsCaisseProPrestashopWebserviceManager($this->configRepository);
            $wsKey = $wsManager->ensureWebserviceKey($shopId);
            $client = new NsCaisseProCashAccountClient($this->configRepository);
            $auth = $client->authenticate($shopId, $login, $password);

            $this->configRepository->savePartialByShopId($shopId, array(
                'api_key' => $auth['api_key'],
                'cash_shop_id' => $auth['shop_id'],
                'connection_status' => 'connected',
                'last_connection_at' => date('Y-m-d H:i:s'),
                'ps_ws_key' => $wsKey,
            ));

            return $this->displayConfirmation($this->l('Connexion caisse réussie.'));
        } catch (Exception $e) {
            return $this->displayError($e->getMessage());
        }
    }

    protected function handleCreateAccountSubmit()
    {
        $shopId = (int) Tools::getValue('id_shop');
        $email = trim((string) Tools::getValue('create_email'));

        if ($shopId <= 0) {
            return $this->displayError($this->l('Boutique invalide.'));
        }

        if (!Validate::isEmail($email)) {
            return $this->displayError($this->l('Email invalide.'));
        }

        try {
            $wsManager = new NsCaisseProPrestashopWebserviceManager($this->configRepository);
            $wsKey = $wsManager->ensureWebserviceKey($shopId);
            $client = new NsCaisseProCashAccountClient($this->configRepository);
            $created = $client->createAccount(
                $shopId,
                $email,
                Configuration::get('PS_SHOP_NAME'),
                $this->context->shop->getBaseURL(true),
                $wsKey
            );

            $this->configRepository->savePartialByShopId($shopId, array(
                'api_key' => $created['api_key'],
                'cash_shop_id' => $created['shop_id'],
                'connection_status' => 'connected',
                'last_connection_at' => date('Y-m-d H:i:s'),
                'ps_ws_key' => $wsKey,
            ));

            return $this->displayConfirmation($this->l('Compte caisse créé et connecté.'));
        } catch (Exception $e) {
            return $this->displayError($e->getMessage());
        }
    }

    protected function handleLogoutSubmit()
    {
        $shopId = (int) Tools::getValue('id_shop');
        if ($shopId <= 0) {
            return $this->displayError($this->l('Boutique invalide.'));
        }

        $this->configRepository->savePartialByShopId($shopId, array(
            'api_key' => '',
            'cash_shop_id' => '',
            'connection_status' => 'disconnected',
        ));

        return $this->displayConfirmation($this->l('Déconnexion effectuée.'));
    }

    protected function handleCreateWsKeySubmit()
    {
        $shopId = (int) Tools::getValue('id_shop');
        if ($shopId <= 0) {
            return $this->displayError($this->l('Boutique invalide.'));
        }

        try {
            $wsManager = new NsCaisseProPrestashopWebserviceManager($this->configRepository);
            $wsManager->clearWebserviceKey($shopId);
            $wsKey = $wsManager->ensureWebserviceKey($shopId);

            return $this->displayConfirmation($this->l('Clé webservice créée : ') . $wsKey);
        } catch (Exception $e) {
            return $this->displayError($e->getMessage());
        }
    }

    protected function handleProductMapSubmit()
    {
        $repository = new NsCaisseProProductRepository();
        return $this->handleJsonMappingSubmit(
            (int) Tools::getValue('id_shop'),
            'product_mappings',
            array('id_product', 'cash_code'),
            array($repository, 'replaceForShop'),
            $this->l('Mappings produits enregistrés.')
        );
    }

    protected function handleCombinationMapSubmit()
    {
        $repository = new NsCaisseProCombinationRepository();
        return $this->handleJsonMappingSubmit(
            (int) Tools::getValue('id_shop'),
            'combination_mappings',
            array('id_product', 'id_product_attribute', 'cash_code'),
            array($repository, 'replaceForShop'),
            $this->l('Mappings déclinaisons enregistrés.')
        );
    }

    protected function handleProductFieldMapSubmit()
    {
        $repository = new NsCaisseProProductFieldRepository();
        return $this->handleJsonMappingSubmit(
            (int) Tools::getValue('id_shop'),
            'productfield_mappings',
            array('field_name', 'field_value', 'cash_code', 'type'),
            array($repository, 'replaceForShop'),
            $this->l('Mappings AN Product Fields enregistrés.')
        );
    }

    protected function handlePaymentMapSubmit()
    {
        $repository = new NsCaisseProPaymentRepository();
        return $this->handleJsonMappingSubmit(
            (int) Tools::getValue('id_shop'),
            'payment_mappings',
            array('payment_module', 'cash_code'),
            array($repository, 'replaceForShop'),
            $this->l('Mappings paiements enregistrés.')
        );
    }

    protected function handleCarrierMapSubmit()
    {
        $repository = new NsCaisseProCarrierRepository();
        return $this->handleJsonMappingSubmit(
            (int) Tools::getValue('id_shop'),
            'carrier_mappings',
            array('id_carrier', 'cash_code'),
            array($repository, 'replaceForShop'),
            $this->l('Mappings transporteurs enregistrés.')
        );
    }

    protected function handleJsonMappingSubmit($shopId, $fieldName, array $requiredKeys, callable $callback, $successMessage)
    {
        if ($shopId <= 0) {
            return $this->displayError($this->l('Boutique invalide.'));
        }

        $raw = trim((string) Tools::getValue($fieldName));
        $decoded = json_decode($raw, true);

        if (!is_array($decoded)) {
            return $this->displayError($this->l('JSON invalide.'));
        }

        foreach ($decoded as $row) {
            if (!is_array($row)) {
                return $this->displayError($this->l('Chaque entrée doit être un objet JSON.'));
            }

            foreach ($requiredKeys as $key) {
                if (!array_key_exists($key, $row)) {
                    return $this->displayError(sprintf($this->l('La clé obligatoire "%s" est manquante.'), $key));
                }
            }
        }

        if (!call_user_func($callback, $shopId, $decoded)) {
            return $this->displayError($this->l('Enregistrement impossible.'));
        }

        return $this->displayConfirmation($successMessage);
    }

    protected function buildOrderSyncService($shopId)
    {
        $configRepository = new NsCaisseProConfigRepository();
        $logger = new NsCaisseProLogger();
        $productRepository = new NsCaisseProProductRepository();
        $combinationRepository = new NsCaisseProCombinationRepository();
        $productFieldRepository = new NsCaisseProProductFieldRepository();
        $paymentRepository = new NsCaisseProPaymentRepository();
        $carrierRepository = new NsCaisseProCarrierRepository();
        $anAdapter = new NsCaisseProAnProductFieldsAdapter();
        $resolver = new NsCaisseProOrderLineResolver(
            $productRepository,
            $combinationRepository,
            $productFieldRepository,
            $anAdapter
        );
        $payloadBuilder = new NsCaisseProOrderPayloadBuilder(
            $resolver,
            $paymentRepository,
            $carrierRepository
        );
        $client = new NsCaisseProCashRegisterClient($configRepository);

        return new NsCaisseProOrderSyncService(
            $shopId,
            $configRepository,
            $payloadBuilder,
            $client,
            $logger
        );
    }
}
